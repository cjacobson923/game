using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class S_Player : MonoBehaviour
{
    public Rigidbody2D playerRB;
    public BoxCollider2D playerColl;
    public float moveStren;
    public float slideStren;
    public float jumpAmount;

    void Update()
    {
        if (Input.GetKey(KeyCode.A))
        {
            playerRB.position += new Vector2(-moveStren * Time.deltaTime, 0);
            if(playerRB.velocity.x > -8)
            {
                playerRB.velocity += new Vector2(-slideStren * Time.deltaTime, 0);
            }
            if(playerRB.velocity.x > 0)
            {
                playerRB.velocity = new Vector2(0, playerRB.velocity.y);
            }
        }
        if (Input.GetKey(KeyCode.D))
        {
            playerRB.position += new Vector2(moveStren * Time.deltaTime, 0);
            if (playerRB.velocity.x < 8)
            {
                playerRB.velocity += new Vector2(slideStren * Time.deltaTime, 0);
            }
            if (playerRB.velocity.x < 0)
            {
                playerRB.velocity = new Vector2(0, playerRB.velocity.y);
            }
        }
        if (Input.GetKeyDown(KeyCode.Space))
        {
            playerRB.AddForce(Vector2.up * jumpAmount, ForceMode2D.Impulse);
        }
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.name == "Ground")
        {
            Debug.Log("AAAHHH");
        }
    }
}
